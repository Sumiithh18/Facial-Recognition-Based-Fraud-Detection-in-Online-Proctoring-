import React, { useRef, useState, useEffect, useCallback } from "react";
import {
  Shield, ShieldAlert, ShieldCheck, Camera, UserPlus,
  AlertTriangle, CheckCircle, XCircle, Eye, Activity,
  Users, LogOut, Loader
} from "lucide-react";

const API = "http://localhost:5000/api";
const CAPTURE_INTERVAL_MS = 2500;

// ── Palette ─────────────────────────────────────────────────────────────────
// Deep navy science-lab aesthetic: trust + surveillance + precision
const C = {
  navy:   "#0b1120",
  panel:  "#111827",
  card:   "#1a2235",
  border: "#243049",
  accent: "#3b82f6",
  live:   "#22c55e",
  spoof:  "#ef4444",
  warn:   "#f59e0b",
  text:   "#e2e8f0",
  muted:  "#64748b",
};

// ── Helpers ──────────────────────────────────────────────────────────────────
function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function Badge({ type }) {
  if (type === "LIVE") return (
    <span style={styles.badgeLive}><CheckCircle size={12}/> LIVE</span>
  );
  if (type === "SPOOF") return (
    <span style={styles.badgeSpoof}><XCircle size={12}/> SPOOF</span>
  );
  return <span style={styles.badgeWarn}><AlertTriangle size={12}/> CHECKING</span>;
}

function AlertBanner({ alert }) {
  if (!alert) return null;
  const isCrit = alert.severity === "critical";
  return (
    <div style={{ ...styles.alertBanner, borderColor: isCrit ? C.spoof : C.warn }}>
      <ShieldAlert size={16} color={isCrit ? C.spoof : C.warn}/>
      <span style={{ color: isCrit ? C.spoof : C.warn, fontWeight: 600 }}>
        {alert.type.replace("_", " ")}:
      </span>
      <span style={{ color: C.text }}>{alert.message}</span>
    </div>
  );
}

function ScoreBar({ label, value }) {
  const pct = Math.round((value ?? 0) * 100);
  const color = pct >= 60 ? C.live : pct >= 40 ? C.warn : C.spoof;
  return (
    <div style={styles.scoreRow}>
      <span style={styles.scoreLabel}>{label}</span>
      <div style={styles.scoreTrack}>
        <div style={{ ...styles.scoreFill, width: `${pct}%`, background: color }}/>
      </div>
      <span style={{ ...styles.scoreNum, color }}>{pct}%</span>
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("exam"); // "exam" | "register" | "history"
  return (
    <div style={styles.root}>
      <Sidebar page={page} setPage={setPage}/>
      <main style={styles.main}>
        {page === "exam"     && <ExamPage/>}
        {page === "register" && <RegisterPage/>}
        {page === "history"  && <HistoryPage/>}
      </main>
    </div>
  );
}

// ── Sidebar ──────────────────────────────────────────────────────────────────
function Sidebar({ page, setPage }) {
  const navItems = [
    { id: "exam",     label: "Exam Monitor",  Icon: Eye },
    { id: "register", label: "Register Face", Icon: UserPlus },
    { id: "history",  label: "Alert History", Icon: Activity },
  ];
  return (
    <nav style={styles.sidebar}>
      <div style={styles.logo}>
        <Shield size={26} color={C.accent}/>
        <div>
          <div style={styles.logoTitle}>ProctorGuard</div>
          <div style={styles.logoSub}>Fraud Detection System</div>
        </div>
      </div>
      <div style={styles.navList}>
        {navItems.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => setPage(id)}
            style={{ ...styles.navBtn, ...(page === id ? styles.navBtnActive : {}) }}
          >
            <Icon size={17}/>
            {label}
          </button>
        ))}
      </div>
      <div style={styles.sidebarFooter}>
        <div style={styles.techLabel}>Technology Stack</div>
        {["Haar Cascade (Detection)", "LBP Features (Texture)", "SVM Classifier (Recognition)"].map(t => (
          <div key={t} style={styles.techItem}>▸ {t}</div>
        ))}
      </div>
    </nav>
  );
}

// ── Exam Monitor Page ─────────────────────────────────────────────────────────
function ExamPage() {
  const videoRef   = useRef(null);
  const canvasRef  = useRef(null);
  const intervalRef = useRef(null);

  const [streaming,    setStreaming]    = useState(false);
  const [monitoring,   setMonitoring]   = useState(false);
  const [sessionId]                     = useState(() => uid());
  const [studentId,    setStudentId]    = useState("");
  const [result,       setResult]       = useState(null);
  const [alertLog,     setAlertLog]     = useState([]);
  const [frameCount,   setFrameCount]   = useState(0);
  const [status,       setStatus]       = useState("idle"); // idle|loading|ok|error

  // Start webcam
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setStreaming(true);
    } catch {
      alert("Camera access denied. Please allow camera permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    const stream = videoRef.current?.srcObject;
    stream?.getTracks().forEach(t => t.stop());
    setStreaming(false);
    setMonitoring(false);
    clearInterval(intervalRef.current);
  }, []);

  const captureFrame = useCallback(() => {
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return null;
    canvas.width  = video.videoWidth  || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext("2d").drawImage(video, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.85);
  }, []);

  const analyzeFrame = useCallback(async () => {
    const image = captureFrame();
    if (!image) return;
    setStatus("loading");
    try {
      const res = await fetch(`${API}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, student_id: studentId, image_b64: image }),
      });
      const data = await res.json();
      setResult(data);
      setFrameCount(n => n + 1);
      if (data.alert) setAlertLog(prev => [data.alert, ...prev].slice(0, 50));
      setStatus("ok");
    } catch {
      setStatus("error");
    }
  }, [captureFrame, sessionId, studentId]);

  const toggleMonitoring = useCallback(() => {
    if (monitoring) {
      clearInterval(intervalRef.current);
      setMonitoring(false);
    } else {
      analyzeFrame();
      intervalRef.current = setInterval(analyzeFrame, CAPTURE_INTERVAL_MS);
      setMonitoring(true);
    }
  }, [monitoring, analyzeFrame]);

  useEffect(() => () => clearInterval(intervalRef.current), []);

  const liveStatus = result?.is_live === true  ? "LIVE"
                   : result?.is_live === false ? "SPOOF"
                   : "CHECKING";

  return (
    <div style={styles.page}>
      <h1 style={styles.pageTitle}><Eye size={22}/> Exam Monitor</h1>
      <p style={styles.pageDesc}>
        Real-time liveness detection and identity verification for online examinations.
      </p>

      <div style={styles.examGrid}>
        {/* Camera panel */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <Camera size={16} color={C.accent}/> Live Feed
            {streaming && <Badge type={liveStatus}/>}
          </div>
          <div style={styles.videoWrap}>
            <video ref={videoRef} style={styles.video} muted playsInline/>
            <canvas ref={canvasRef} style={{ display: "none" }}/>
            {!streaming && (
              <div style={styles.videoPlaceholder}>
                <Camera size={40} color={C.muted}/>
                <span style={{ color: C.muted }}>Camera off</span>
              </div>
            )}
          </div>

          {/* Controls */}
          <div style={styles.controls}>
            <input
              placeholder="Student ID (optional)"
              value={studentId}
              onChange={e => setStudentId(e.target.value)}
              style={styles.input}
            />
            {!streaming ? (
              <button onClick={startCamera} style={styles.btnPrimary}>
                <Camera size={15}/> Start Camera
              </button>
            ) : (
              <>
                <button
                  onClick={toggleMonitoring}
                  style={monitoring ? styles.btnDanger : styles.btnSuccess}
                >
                  {monitoring
                    ? <><LogOut size={15}/> Stop Monitor</>
                    : <><Eye size={15}/> Start Monitor</>}
                </button>
                <button onClick={stopCamera} style={styles.btnMuted}>
                  Stop Camera
                </button>
              </>
            )}
          </div>

          {/* LBP visualisation */}
          {result?.lbp_image && (
            <div style={styles.lbpWrap}>
              <div style={styles.lbpLabel}>LBP Texture Analysis</div>
              <img src={result.lbp_image} alt="LBP" style={styles.lbpImg}/>
            </div>
          )}
        </div>

        {/* Analysis panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Analysis result card */}
          <div style={styles.card}>
            <div style={styles.cardHeader}>
              <Activity size={16} color={C.accent}/> Analysis Result
              <span style={styles.sessionTag}>Session: {sessionId.slice(0,6)}…</span>
            </div>

            <AlertBanner alert={result?.alert}/>

            <div style={styles.statsGrid}>
              <Stat label="Frames" value={frameCount}/>
              <Stat label="Faces Detected" value={result?.face_count ?? "—"}/>
              <Stat label="Alerts" value={alertLog.length} warn={alertLog.length > 0}/>
              <Stat label="Status"
                value={status === "loading" ? "…" : status === "error" ? "ERR" : streaming ? "ON" : "OFF"}
                live={status === "ok"}/>
            </div>

            {result && (
              <div style={styles.scores}>
                <ScoreBar label="Liveness Score" value={result.liveness_score}/>
                <ScoreBar label="Identity Confidence" value={result.identity_confidence}/>
              </div>
            )}

            {result?.spoof_type && (
              <div style={styles.spoofTag}>
                <ShieldAlert size={14}/> Spoof type: {result.spoof_type.replace(/_/g, " ")}
              </div>
            )}

            {result?.annotated_image && (
              <div>
                <div style={styles.lbpLabel}>Annotated Frame</div>
                <img src={result.annotated_image} alt="Annotated" style={styles.annotatedImg}/>
              </div>
            )}
          </div>

          {/* Alert log */}
          <div style={{ ...styles.card, flex: 1 }}>
            <div style={styles.cardHeader}>
              <ShieldAlert size={16} color={C.accent}/> Alert Log
            </div>
            {alertLog.length === 0
              ? <div style={styles.empty}>No alerts recorded.</div>
              : <div style={styles.alertList}>
                  {alertLog.map((a, i) => (
                    <div key={i} style={styles.alertItem}>
                      <span style={{ color: a.severity === "critical" ? C.spoof : C.warn }}>
                        ● {a.type.replace(/_/g, " ")}
                      </span>
                      <span style={{ color: C.muted, fontSize: 11 }}>
                        {new Date(a.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
                </div>
            }
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, warn, live }) {
  return (
    <div style={styles.stat}>
      <div style={{ ...styles.statValue, color: warn ? C.warn : live ? C.live : C.text }}>
        {value}
      </div>
      <div style={styles.statLabel}>{label}</div>
    </div>
  );
}

// ── Register Page ────────────────────────────────────────────────────────────
function RegisterPage() {
  const videoRef  = useRef(null);
  const canvasRef = useRef(null);
  const [streaming, setStreaming] = useState(false);
  const [studentId, setStudentId] = useState("");
  const [name,      setName]      = useState("");
  const [preview,   setPreview]   = useState(null);
  const [status,    setStatus]    = useState(null); // null | "loading" | "ok" | "error"
  const [message,   setMessage]   = useState("");
  const [students,  setStudents]  = useState([]);

  useEffect(() => { loadStudents(); }, []);

  async function loadStudents() {
    try {
      const r = await fetch(`${API}/registered_students`);
      const d = await r.json();
      setStudents(d.students || []);
    } catch {}
  }

  async function startCamera() {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    videoRef.current.srcObject = stream;
    await videoRef.current.play();
    setStreaming(true);
  }

  function capture() {
    const v = videoRef.current, c = canvasRef.current;
    c.width  = v.videoWidth;
    c.height = v.videoHeight;
    c.getContext("2d").drawImage(v, 0, 0);
    setPreview(c.toDataURL("image/jpeg", 0.9));
  }

  async function register() {
    if (!studentId || !name || !preview) return;
    setStatus("loading");
    try {
      const res = await fetch(`${API}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ student_id: studentId, name, image_b64: preview }),
      });
      const d = await res.json();
      if (d.success) {
        setStatus("ok");
        setMessage(d.message);
        loadStudents();
      } else {
        setStatus("error");
        setMessage(d.error);
      }
    } catch {
      setStatus("error");
      setMessage("Server unreachable");
    }
  }

  return (
    <div style={styles.page}>
      <h1 style={styles.pageTitle}><UserPlus size={22}/> Register Student Face</h1>
      <p style={styles.pageDesc}>
        Capture and register a student's face for identity verification during exams.
      </p>

      <div style={styles.examGrid}>
        <div style={styles.card}>
          <div style={styles.cardHeader}><Camera size={16} color={C.accent}/> Capture</div>
          <div style={styles.videoWrap}>
            <video ref={videoRef} style={styles.video} muted playsInline/>
            <canvas ref={canvasRef} style={{ display:"none" }}/>
            {!streaming && (
              <div style={styles.videoPlaceholder}>
                <Camera size={40} color={C.muted}/>
              </div>
            )}
          </div>
          <div style={styles.controls}>
            {!streaming
              ? <button onClick={startCamera} style={styles.btnPrimary}><Camera size={15}/> Start Camera</button>
              : <button onClick={capture}     style={styles.btnSuccess}><Camera size={15}/> Capture Photo</button>
            }
          </div>
          {preview && <img src={preview} alt="preview" style={{ ...styles.annotatedImg, marginTop: 12 }}/>}
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}><UserPlus size={16} color={C.accent}/> Student Details</div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Student ID</label>
            <input value={studentId} onChange={e => setStudentId(e.target.value)} style={styles.input} placeholder="e.g. STU001"/>
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Full Name</label>
            <input value={name} onChange={e => setName(e.target.value)} style={styles.input} placeholder="e.g. Arjun Kumar"/>
          </div>
          <button
            onClick={register}
            disabled={!studentId || !name || !preview || status === "loading"}
            style={{ ...styles.btnPrimary, width: "100%", marginTop: 8, opacity: (!studentId || !name || !preview) ? 0.4 : 1 }}
          >
            {status === "loading" ? <><Loader size={14}/> Registering…</> : <><ShieldCheck size={14}/> Register Face</>}
          </button>

          {status === "ok"    && <div style={styles.successMsg}><CheckCircle size={14}/> {message}</div>}
          {status === "error" && <div style={styles.errorMsg}><XCircle size={14}/> {message}</div>}

          <div style={{ marginTop: 24 }}>
            <div style={styles.cardHeader}><Users size={16} color={C.accent}/> Registered Students ({students.length})</div>
            {students.length === 0
              ? <div style={styles.empty}>No students registered yet.</div>
              : students.map(s => (
                  <div key={s.id} style={styles.studentRow}>
                    <span style={{ color: C.text }}>{s.name}</span>
                    <span style={{ color: C.muted, fontSize: 12 }}>{s.id}</span>
                  </div>
                ))
            }
          </div>
        </div>
      </div>
    </div>
  );
}

// ── History Page ─────────────────────────────────────────────────────────────
function HistoryPage() {
  const [sessionId, setSessionId] = useState("");
  const [data,      setData]      = useState(null);
  const [loading,   setLoading]   = useState(false);

  async function fetch_() {
    if (!sessionId) return;
    setLoading(true);
    try {
      const r = await fetch(`${API}/session/${sessionId}`);
      setData(await r.json());
    } catch {}
    setLoading(false);
  }

  return (
    <div style={styles.page}>
      <h1 style={styles.pageTitle}><Activity size={22}/> Alert History</h1>
      <p style={styles.pageDesc}>Look up the alert log for any examination session.</p>

      <div style={{ ...styles.card, maxWidth: 640, marginBottom: 24 }}>
        <div style={styles.cardHeader}><Eye size={16} color={C.accent}/> Session Lookup</div>
        <div style={{ display:"flex", gap:8, marginTop:8 }}>
          <input
            value={sessionId}
            onChange={e => setSessionId(e.target.value)}
            placeholder="Enter Session ID"
            style={{ ...styles.input, flex:1 }}
          />
          <button onClick={fetch_} style={styles.btnPrimary} disabled={loading}>
            {loading ? "…" : "Fetch"}
          </button>
        </div>
      </div>

      {data && (
        <div style={styles.card}>
          <div style={styles.cardHeader}><Activity size={16} color={C.accent}/> Session: {data.session_id}</div>
          <div style={styles.statsGrid}>
            <Stat label="Total Frames" value={data.total_frames}/>
            <Stat label="Total Alerts"  value={data.alert_count} warn={data.alert_count > 0}/>
          </div>
          {data.alerts.length === 0
            ? <div style={styles.empty}>No alerts in this session.</div>
            : data.alerts.map((a, i) => (
                <div key={i} style={{ ...styles.alertItem, marginBottom: 8 }}>
                  <span style={{ color: C.warn }}>{a.alert.replace(/_/g," ")}</span>
                  <span style={{ color: C.muted, fontSize: 12 }}>{new Date(a.timestamp).toLocaleString()}</span>
                </div>
              ))
          }
        </div>
      )}
    </div>
  );
}

// ── Styles ───────────────────────────────────────────────────────────────────
const styles = {
  root:         { display:"flex", minHeight:"100vh", background:C.navy, fontFamily:"'Inter',system-ui,sans-serif", color:C.text },
  sidebar:      { width:230, background:C.panel, borderRight:`1px solid ${C.border}`, display:"flex", flexDirection:"column", padding:"24px 0", flexShrink:0 },
  logo:         { display:"flex", alignItems:"center", gap:10, padding:"0 20px 24px", borderBottom:`1px solid ${C.border}`, marginBottom:12 },
  logoTitle:    { fontWeight:700, fontSize:16, color:C.text, letterSpacing:"0.02em" },
  logoSub:      { fontSize:10, color:C.muted, marginTop:2 },
  navList:      { flex:1, padding:"0 12px", display:"flex", flexDirection:"column", gap:4 },
  navBtn:       { display:"flex", alignItems:"center", gap:10, padding:"10px 12px", borderRadius:8, border:"none", background:"transparent", color:C.muted, fontSize:14, cursor:"pointer", textAlign:"left", width:"100%", transition:"all .15s" },
  navBtnActive: { background:C.accent+"22", color:C.accent },
  sidebarFooter:{ padding:"20px 20px 0", borderTop:`1px solid ${C.border}`, marginTop:"auto" },
  techLabel:    { fontSize:10, fontWeight:700, color:C.muted, letterSpacing:"0.1em", textTransform:"uppercase", marginBottom:8 },
  techItem:     { fontSize:11, color:C.muted, marginBottom:4 },
  main:         { flex:1, overflow:"auto" },
  page:         { padding:"28px 32px", maxWidth:1100 },
  pageTitle:    { fontSize:22, fontWeight:700, display:"flex", alignItems:"center", gap:10, marginBottom:6 },
  pageDesc:     { color:C.muted, marginBottom:24, fontSize:14 },
  examGrid:     { display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, alignItems:"start" },
  card:         { background:C.card, border:`1px solid ${C.border}`, borderRadius:12, padding:20 },
  cardHeader:   { display:"flex", alignItems:"center", gap:8, fontSize:13, fontWeight:600, color:C.text, marginBottom:14, paddingBottom:10, borderBottom:`1px solid ${C.border}` },
  videoWrap:    { position:"relative", borderRadius:8, overflow:"hidden", background:"#000", aspectRatio:"4/3", display:"flex", alignItems:"center", justifyContent:"center" },
  video:        { width:"100%", height:"100%", objectFit:"cover" },
  videoPlaceholder: { position:"absolute", display:"flex", flexDirection:"column", alignItems:"center", gap:8 },
  controls:     { display:"flex", gap:8, marginTop:14, flexWrap:"wrap" },
  input:        { flex:1, background:C.panel, border:`1px solid ${C.border}`, borderRadius:8, padding:"8px 12px", color:C.text, fontSize:13, outline:"none", minWidth:0 },
  btnPrimary:   { display:"flex", alignItems:"center", gap:6, padding:"8px 16px", borderRadius:8, border:"none", background:C.accent, color:"#fff", fontSize:13, fontWeight:600, cursor:"pointer" },
  btnSuccess:   { display:"flex", alignItems:"center", gap:6, padding:"8px 16px", borderRadius:8, border:"none", background:C.live, color:"#fff", fontSize:13, fontWeight:600, cursor:"pointer" },
  btnDanger:    { display:"flex", alignItems:"center", gap:6, padding:"8px 16px", borderRadius:8, border:"none", background:C.spoof, color:"#fff", fontSize:13, fontWeight:600, cursor:"pointer" },
  btnMuted:     { display:"flex", alignItems:"center", gap:6, padding:"8px 12px", borderRadius:8, border:`1px solid ${C.border}`, background:"transparent", color:C.muted, fontSize:13, cursor:"pointer" },
  lbpWrap:      { marginTop:14 },
  lbpLabel:     { fontSize:11, color:C.muted, marginBottom:6, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.08em" },
  lbpImg:       { width:"100%", borderRadius:6 },
  annotatedImg: { width:"100%", borderRadius:6 },
  alertBanner:  { display:"flex", alignItems:"center", gap:8, padding:"10px 14px", borderRadius:8, border:"1px solid", background:C.panel, marginBottom:14, fontSize:13, flexWrap:"wrap" },
  statsGrid:    { display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12, marginBottom:16 },
  stat:         { background:C.panel, borderRadius:8, padding:"12px 8px", textAlign:"center" },
  statValue:    { fontSize:22, fontWeight:700 },
  statLabel:    { fontSize:10, color:C.muted, marginTop:2, textTransform:"uppercase" },
  scores:       { display:"flex", flexDirection:"column", gap:10, marginBottom:16 },
  scoreRow:     { display:"flex", alignItems:"center", gap:10 },
  scoreLabel:   { fontSize:12, color:C.muted, width:130, flexShrink:0 },
  scoreTrack:   { flex:1, height:6, borderRadius:99, background:C.panel, overflow:"hidden" },
  scoreFill:    { height:"100%", borderRadius:99, transition:"width .4s ease" },
  scoreNum:     { fontSize:12, fontWeight:700, width:36, textAlign:"right" },
  spoofTag:     { display:"flex", alignItems:"center", gap:6, fontSize:12, color:C.spoof, padding:"6px 10px", borderRadius:6, background:C.spoof+"18", marginBottom:12 },
  sessionTag:   { marginLeft:"auto", fontSize:11, color:C.muted },
  alertList:    { display:"flex", flexDirection:"column", gap:4, maxHeight:200, overflow:"auto" },
  alertItem:    { display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 10px", borderRadius:6, background:C.panel, fontSize:12 },
  empty:        { color:C.muted, fontSize:13, padding:"12px 0", textAlign:"center" },
  formGroup:    { marginBottom:14 },
  label:        { display:"block", fontSize:12, color:C.muted, marginBottom:6, fontWeight:600 },
  successMsg:   { display:"flex", alignItems:"center", gap:6, color:C.live, fontSize:13, marginTop:10 },
  errorMsg:     { display:"flex", alignItems:"center", gap:6, color:C.spoof, fontSize:13, marginTop:10 },
  studentRow:   { display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid ${C.border}`, fontSize:13 },
  badgeLive:    { display:"inline-flex", alignItems:"center", gap:4, background:C.live+"22", color:C.live, borderRadius:99, padding:"2px 8px", fontSize:11, fontWeight:700, marginLeft:"auto" },
  badgeSpoof:   { display:"inline-flex", alignItems:"center", gap:4, background:C.spoof+"22", color:C.spoof, borderRadius:99, padding:"2px 8px", fontSize:11, fontWeight:700, marginLeft:"auto" },
  badgeWarn:    { display:"inline-flex", alignItems:"center", gap:4, background:C.warn+"22", color:C.warn, borderRadius:99, padding:"2px 8px", fontSize:11, fontWeight:700, marginLeft:"auto" },
};
