"""
LivenessDetector — LBP-based face anti-spoofing.

Pipeline:
  1. Crop face ROI
  2. Apply Local Binary Pattern (LBP) to detect texture micro-patterns
  3. Analyse light-reflection histogram variance
  4. Classify LIVE vs SPOOF using SVM trained on LBP histograms

When no trained model is available (first run), the detector falls back to a
rule-based heuristic so the system is still usable out of the box.
"""

import cv2
import numpy as np
import os
import pickle
from skimage.feature import local_binary_pattern
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler


MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "liveness_svm.pkl")
SCALER_PATH = os.path.join(os.path.dirname(__file__), "models", "liveness_scaler.pkl")

# LBP parameters
LBP_RADIUS = 1
LBP_POINTS = 8 * LBP_RADIUS   # 8
LBP_METHOD = "uniform"
HIST_BINS = 59   # uniform LBP with P=8 → 59 uniform patterns


class LivenessDetector:
    def __init__(self):
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        self.svm = None
        self.scaler = None
        self._load_model()

    # ── Public API ────────────────────────────────────────────────────────────

    def check(self, img: np.ndarray, face_rect: tuple) -> dict:
        """
        Run liveness check on the detected face region.
        Returns dict with: is_live, score, spoof_type, lbp_visualization
        """
        x, y, w, h = face_rect
        face_roi = img[y:y+h, x:x+w]

        if face_roi.size == 0:
            return self._result(False, 0.0, "NO_FACE_ROI", img)

        gray_roi = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY)
        gray_roi = cv2.resize(gray_roi, (128, 128))

        # LBP feature vector
        lbp_hist = self._compute_lbp_histogram(gray_roi)
        lbp_vis = self._lbp_visualization(gray_roi, img, face_rect)

        # Light reflection score
        reflection_score = self._light_reflection_score(face_roi)

        if self.svm is not None:
            score = self._svm_score(lbp_hist)
        else:
            # Heuristic fallback
            score = self._heuristic_score(lbp_hist, reflection_score)

        is_live = score >= 0.5
        spoof_type = None if is_live else self._classify_spoof(reflection_score, lbp_hist)

        return self._result(is_live, score, spoof_type, lbp_vis)

    def train(self, live_images: list, spoof_images: list):
        """
        Train the SVM classifier on labeled images.
        live_images / spoof_images: list of BGR np.ndarray face crops (128×128 grey)
        """
        X, y = [], []
        for img in live_images:
            X.append(self._extract_features(img))
            y.append(1)
        for img in spoof_images:
            X.append(self._extract_features(img))
            y.append(0)

        X = np.array(X)
        y = np.array(y)

        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)

        self.svm = SVC(kernel="rbf", C=1.0, gamma="scale", probability=True)
        self.svm.fit(X_scaled, y)

        with open(MODEL_PATH, "wb") as f:
            pickle.dump(self.svm, f)
        with open(SCALER_PATH, "wb") as f:
            pickle.dump(self.scaler, f)

        return {"trained": True, "samples": len(y)}

    # ── Private helpers ───────────────────────────────────────────────────────

    def _load_model(self):
        if os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH):
            try:
                with open(MODEL_PATH, "rb") as f:
                    self.svm = pickle.load(f)
                with open(SCALER_PATH, "rb") as f:
                    self.scaler = pickle.load(f)
            except Exception:
                self.svm = None
                self.scaler = None

    def _compute_lbp_histogram(self, gray: np.ndarray) -> np.ndarray:
        lbp = local_binary_pattern(gray, LBP_POINTS, LBP_RADIUS, LBP_METHOD)
        hist, _ = np.histogram(lbp.ravel(), bins=HIST_BINS, range=(0, HIST_BINS))
        hist = hist.astype(float)
        hist /= (hist.sum() + 1e-7)
        return hist

    def _extract_features(self, img: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
        gray = cv2.resize(gray, (128, 128))
        lbp_hist = self._compute_lbp_histogram(gray)
        refl = np.array([self._light_reflection_score(img)])
        return np.concatenate([lbp_hist, refl])

    def _light_reflection_score(self, face_roi: np.ndarray) -> float:
        """
        Estimate light reflection variation.
        Real faces: smooth gradients due to 3D curvature → moderate local variance.
        Printed photos: flat surface → uniform reflection → low local variance.
        Screen spoofs: high-frequency brightness jumps.
        """
        if face_roi.size == 0:
            return 0.0
        gray = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY) if face_roi.ndim == 3 else face_roi
        gray = cv2.resize(gray, (64, 64)).astype(np.float32)

        # Local variance map
        blur = cv2.GaussianBlur(gray, (7, 7), 0)
        diff = gray - blur
        local_var = np.var(diff)

        # Specular highlight ratio (very bright regions)
        bright_ratio = np.sum(gray > 220) / gray.size

        # Combine: real faces have moderate variance, some highlights
        score = np.tanh(local_var / 50.0) * 0.7 + min(bright_ratio * 5, 0.3)
        return float(np.clip(score, 0.0, 1.0))

    def _heuristic_score(self, lbp_hist: np.ndarray, reflection_score: float) -> float:
        """
        Rule-based liveness score when no trained model exists.
        Uses LBP entropy + reflection variance.
        """
        # Entropy of LBP distribution — real faces have richer texture
        eps = 1e-10
        entropy = -np.sum(lbp_hist * np.log2(lbp_hist + eps))
        max_entropy = np.log2(HIST_BINS)
        norm_entropy = entropy / max_entropy  # 0..1

        score = 0.6 * norm_entropy + 0.4 * reflection_score
        return float(np.clip(score, 0.0, 1.0))

    def _svm_score(self, lbp_hist: np.ndarray) -> float:
        feat = lbp_hist.reshape(1, -1)
        feat_scaled = self.scaler.transform(feat)
        proba = self.svm.predict_proba(feat_scaled)[0]
        return float(proba[1])   # probability of class "live"

    def _classify_spoof(self, reflection_score: float, lbp_hist: np.ndarray) -> str:
        eps = 1e-10
        entropy = -np.sum(lbp_hist * np.log2(lbp_hist + eps)) / np.log2(HIST_BINS)
        if reflection_score > 0.7:
            return "SCREEN_REPLAY"
        elif entropy < 0.55:
            return "PRINTED_PHOTO"
        else:
            return "UNKNOWN_SPOOF"

    def _lbp_visualization(self, gray_roi: np.ndarray, original_img: np.ndarray,
                            face_rect: tuple) -> np.ndarray:
        """
        Build a side-by-side visualization: original + LBP pattern map.
        """
        lbp = local_binary_pattern(gray_roi, LBP_POINTS, LBP_RADIUS, LBP_METHOD)
        lbp_norm = cv2.normalize(lbp, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        lbp_color = cv2.applyColorMap(lbp_norm, cv2.COLORMAP_JET)

        x, y, w, h = face_rect
        face_crop = original_img[y:y+h, x:x+w]
        face_resized = cv2.resize(face_crop, (128, 128))
        side_by_side = np.hstack([face_resized, lbp_color])

        cv2.putText(side_by_side, "Face ROI", (4, 16),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
        cv2.putText(side_by_side, "LBP Pattern", (132, 16),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
        return side_by_side

    @staticmethod
    def _result(is_live, score, spoof_type, lbp_vis) -> dict:
        return {
            "is_live": is_live,
            "score": score,
            "spoof_type": spoof_type,
            "lbp_visualization": lbp_vis,
        }
