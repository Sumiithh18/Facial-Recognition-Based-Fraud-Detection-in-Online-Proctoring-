"""
FaceRecognizer — SVM classifier trained on LBP facial features.

Uses scikit-learn's SVC with an RBF kernel. When fewer than 2 distinct
students are registered the model cannot be fitted; in that case
recognize() returns a "not_enough_data" result rather than crashing.
"""

import cv2
import numpy as np
import os
import pickle
from skimage.feature import local_binary_pattern
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler
from typing import Optional


MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "recognition_svm.pkl")
META_PATH = os.path.join(os.path.dirname(__file__), "models", "recognition_meta.pkl")

LBP_RADIUS = 2
LBP_POINTS = 16
LBP_METHOD = "uniform"
FACE_SIZE = (100, 100)


class FaceRecognizer:
    def __init__(self):
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        self.svm: Optional[SVC] = None
        self.scaler: Optional[StandardScaler] = None
        self.label_encoder: Optional[LabelEncoder] = None
        self._students: dict = {}   # id -> name
        self._faces: list = []      # list of (student_id, feature_vector)
        self._load_model()

    # ── Public API ────────────────────────────────────────────────────────────

    def register(self, student_id: str, name: str, img: np.ndarray, face_rect: tuple) -> bool:
        """Extract LBP features from registered face and re-train model."""
        try:
            feat = self._extract(img, face_rect)
        except Exception:
            return False

        self._students[student_id] = name
        self._faces.append((student_id, feat))

        # Re-train whenever we have ≥2 distinct students
        ids = [f[0] for f in self._faces]
        if len(set(ids)) >= 2:
            self._train()

        self._save_meta()
        return True

    def recognize(self, img: np.ndarray, face_rect: tuple) -> dict:
        """Identify a face. Returns match flag, matched_id, name, confidence."""
        base = {"match": False, "matched_id": None, "name": None, "confidence": 0.0}

        if self.svm is None or len(set(f[0] for f in self._faces)) < 2:
            base["error"] = "not_enough_data"
            return base

        try:
            feat = self._extract(img, face_rect).reshape(1, -1)
            feat_scaled = self.scaler.transform(feat)
            proba = self.svm.predict_proba(feat_scaled)[0]
            pred_label = self.svm.predict(feat_scaled)[0]
            confidence = float(np.max(proba))
            matched_id = self.label_encoder.inverse_transform([pred_label])[0]

            return {
                "match": confidence >= 0.55,
                "matched_id": matched_id,
                "name": self._students.get(matched_id, "Unknown"),
                "confidence": confidence,
            }
        except Exception as e:
            base["error"] = str(e)
            return base

    def has_registered_faces(self) -> bool:
        return len(self._faces) > 0

    def list_students(self) -> list:
        return [{"id": k, "name": v} for k, v in self._students.items()]

    # ── Private helpers ───────────────────────────────────────────────────────

    def _extract(self, img: np.ndarray, face_rect: tuple) -> np.ndarray:
        x, y, w, h = face_rect
        face = img[y:y+h, x:x+w]
        gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, FACE_SIZE)
        gray = cv2.equalizeHist(gray)

        # Multi-scale LBP
        hists = []
        for r in [1, 2, 3]:
            lbp = local_binary_pattern(gray, 8 * r, r, LBP_METHOD)
            bins = 59 if r == 1 else (int(8 * r * (8 * r - 1) / 2) + 3)
            bins = min(bins, 256)
            h_lbp, _ = np.histogram(lbp.ravel(), bins=bins, range=(0, bins))
            h_lbp = h_lbp.astype(float) / (h_lbp.sum() + 1e-7)
            hists.append(h_lbp)

        return np.concatenate(hists)

    def _train(self):
        X = np.array([f[1] for f in self._faces])
        y_raw = [f[0] for f in self._faces]

        self.label_encoder = LabelEncoder()
        y = self.label_encoder.fit_transform(y_raw)

        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)

        self.svm = SVC(kernel="rbf", C=5.0, gamma="scale", probability=True)
        self.svm.fit(X_scaled, y)

        with open(MODEL_PATH, "wb") as f:
            pickle.dump((self.svm, self.scaler, self.label_encoder), f)

    def _save_meta(self):
        with open(META_PATH, "wb") as f:
            pickle.dump((self._students, self._faces), f)

    def _load_model(self):
        if os.path.exists(MODEL_PATH):
            try:
                with open(MODEL_PATH, "rb") as f:
                    self.svm, self.scaler, self.label_encoder = pickle.load(f)
            except Exception:
                pass
        if os.path.exists(META_PATH):
            try:
                with open(META_PATH, "rb") as f:
                    self._students, self._faces = pickle.load(f)
            except Exception:
                pass
