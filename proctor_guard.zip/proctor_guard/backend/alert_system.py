"""
AlertSystem — generates structured alert payloads.
"""

from datetime import datetime


ALERT_MESSAGES = {
    "NO_FACE":           "No face detected in frame",
    "MULTIPLE_FACES":    "Multiple faces detected — only one examinee allowed",
    "SPOOF_DETECTED":    "Spoof attack detected",
    "IDENTITY_MISMATCH": "Face does not match registered student",
    "LOW_LIVENESS":      "Liveness score below threshold",
}

ALERT_SEVERITY = {
    "NO_FACE":           "warning",
    "MULTIPLE_FACES":    "critical",
    "SPOOF_DETECTED":    "critical",
    "IDENTITY_MISMATCH": "critical",
    "LOW_LIVENESS":      "warning",
}


class AlertSystem:
    def create_alert(self, alert_type: str, session_id: str = None, extra: str = None) -> dict:
        message = ALERT_MESSAGES.get(alert_type, alert_type)
        if extra:
            message = f"{message} ({extra.replace('_', ' ').title()})"

        return {
            "type": alert_type,
            "severity": ALERT_SEVERITY.get(alert_type, "info"),
            "message": message,
            "session_id": session_id,
            "timestamp": datetime.now().isoformat(),
        }
