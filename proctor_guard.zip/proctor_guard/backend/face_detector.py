"""
FaceDetector — Haar Cascade based face detection with annotation.
"""

import cv2
import numpy as np
import os


HAAR_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"


class FaceDetector:
    def __init__(self):
        self.cascade = cv2.CascadeClassifier(HAAR_PATH)
        if self.cascade.empty():
            raise RuntimeError(f"Could not load Haar cascade from {HAAR_PATH}")

    def detect(self, img: np.ndarray):
        """
        Detect faces in image.
        Returns (faces_list, annotated_image).
        faces_list: list of (x, y, w, h) tuples sorted by area descending.
        """
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)

        faces_raw = self.cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(60, 60),
            flags=cv2.CASCADE_SCALE_IMAGE,
        )

        annotated = img.copy()
        faces = []

        if len(faces_raw) > 0:
            # Sort by area descending
            faces = sorted(
                [tuple(f) for f in faces_raw],
                key=lambda f: f[2] * f[3],
                reverse=True,
            )
            for i, (x, y, w, h) in enumerate(faces):
                color = (0, 200, 100) if i == 0 else (0, 100, 255)
                cv2.rectangle(annotated, (x, y), (x + w, y + h), color, 2)
                label = "Primary" if i == 0 else f"Face {i+1}"
                cv2.putText(
                    annotated, label, (x, y - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2
                )

        return faces, annotated

    def annotate(self, img: np.ndarray, faces, result: dict) -> np.ndarray:
        """Draw full analysis result overlay on image."""
        annotated = img.copy()
        h_img, w_img = annotated.shape[:2]

        for i, (x, y, w, h) in enumerate(faces):
            is_live = result.get("is_live")
            if is_live is True:
                box_color = (0, 220, 80)   # green
            elif is_live is False:
                box_color = (0, 60, 255)   # red
            else:
                box_color = (200, 200, 0)  # yellow

            cv2.rectangle(annotated, (x, y), (x + w, y + h), box_color, 2)

            # Liveness badge
            score = result.get("liveness_score", 0.0)
            status_text = "LIVE" if is_live else ("SPOOF" if is_live is False else "?")
            badge = f"{status_text}  {score:.0%}"
            cv2.rectangle(annotated, (x, y + h), (x + w, y + h + 24), box_color, -1)
            cv2.putText(
                annotated, badge, (x + 4, y + h + 17),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1
            )

        # Alert banner
        alert = result.get("alert")
        if alert:
            banner_color = (0, 30, 200)
            cv2.rectangle(annotated, (0, 0), (w_img, 30), banner_color, -1)
            cv2.putText(
                annotated, f"ALERT: {alert.get('message', '')}",
                (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1
            )

        return annotated
