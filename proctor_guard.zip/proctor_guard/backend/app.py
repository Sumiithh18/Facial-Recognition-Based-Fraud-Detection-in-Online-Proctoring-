"""
ProctorGuard Backend - Fraud Detection using Facial Recognition
Uses: OpenCV Haar Cascade, LBP Feature Extraction, SVM Classifier
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
import base64
import os
import logging
from datetime import datetime
from face_detector import FaceDetector
from liveness_detector import LivenessDetector
from face_recognizer import FaceRecognizer
from alert_system import AlertSystem

app = Flask(__name__)
CORS(app)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize modules
face_detector = FaceDetector()
liveness_detector = LivenessDetector()
face_recognizer = FaceRecognizer()
alert_system = AlertSystem()

# In-memory session store
sessions = {}


def decode_image(b64_string: str) -> np.ndarray:
    """Decode base64 image string to OpenCV BGR array."""
    if "," in b64_string:
        b64_string = b64_string.split(",")[1]
    img_bytes = base64.b64decode(b64_string)
    np_arr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    return img


def encode_image(img: np.ndarray) -> str:
    """Encode OpenCV image to base64 PNG string."""
    _, buffer = cv2.imencode(".png", img)
    return "data:image/png;base64," + base64.b64encode(buffer).decode("utf-8")


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "timestamp": datetime.now().isoformat()})


@app.route("/api/register", methods=["POST"])
def register_face():
    """
    Register a student's face for later recognition.
    Expects: { student_id, name, image_b64 }
    """
    data = request.json
    student_id = data.get("student_id")
    name = data.get("name")
    image_b64 = data.get("image_b64")

    if not all([student_id, name, image_b64]):
        return jsonify({"success": False, "error": "Missing fields"}), 400

    img = decode_image(image_b64)
    if img is None:
        return jsonify({"success": False, "error": "Invalid image"}), 400

    # Detect face
    faces, annotated = face_detector.detect(img)
    if len(faces) == 0:
        return jsonify({"success": False, "error": "No face detected in registration image"}), 400

    # Extract and store face features
    success = face_recognizer.register(student_id, name, img, faces[0])
    if not success:
        return jsonify({"success": False, "error": "Could not extract face features"}), 500

    return jsonify({
        "success": True,
        "message": f"Face registered for {name}",
        "annotated_image": encode_image(annotated)
    })


@app.route("/api/analyze", methods=["POST"])
def analyze_frame():
    """
    Analyze a webcam frame for:
      1. Face detection (Haar cascade)
      2. Liveness detection (LBP + light reflection)
      3. Face recognition (SVM on LBP features)
    Expects: { session_id, student_id, image_b64 }
    """
    data = request.json
    session_id = data.get("session_id")
    student_id = data.get("student_id")
    image_b64 = data.get("image_b64")

    if not image_b64:
        return jsonify({"success": False, "error": "No image provided"}), 400

    img = decode_image(image_b64)
    if img is None:
        return jsonify({"success": False, "error": "Invalid image data"}), 400

    result = {
        "timestamp": datetime.now().isoformat(),
        "face_detected": False,
        "face_count": 0,
        "is_live": None,
        "liveness_score": 0.0,
        "identity_match": None,
        "identity_confidence": 0.0,
        "spoof_type": None,
        "alert": None,
        "annotated_image": None,
        "lbp_image": None,
    }

    # ── Step 1: Face Detection ──────────────────────────────────────────────
    faces, annotated_img = face_detector.detect(img)
    result["face_count"] = len(faces)

    if len(faces) == 0:
        result["alert"] = alert_system.create_alert("NO_FACE", session_id)
        result["annotated_image"] = encode_image(annotated_img)
        return jsonify(result)

    if len(faces) > 1:
        result["alert"] = alert_system.create_alert("MULTIPLE_FACES", session_id)

    result["face_detected"] = True
    face_rect = faces[0]  # Use largest/first face

    # ── Step 2: Liveness Detection (LBP + light reflection) ─────────────────
    liveness_result = liveness_detector.check(img, face_rect)
    result["is_live"] = liveness_result["is_live"]
    result["liveness_score"] = liveness_result["score"]
    result["lbp_image"] = encode_image(liveness_result["lbp_visualization"])

    if not liveness_result["is_live"]:
        result["spoof_type"] = liveness_result["spoof_type"]
        result["alert"] = alert_system.create_alert("SPOOF_DETECTED", session_id,
                                                     extra=liveness_result["spoof_type"])

    # ── Step 3: Face Recognition (SVM) ──────────────────────────────────────
    if student_id and face_recognizer.has_registered_faces():
        recognition = face_recognizer.recognize(img, face_rect)
        result["identity_match"] = recognition["match"]
        result["identity_confidence"] = recognition["confidence"]

        if recognition["match"] and recognition["matched_id"] != student_id:
            result["alert"] = alert_system.create_alert("IDENTITY_MISMATCH", session_id)

    # Annotate final image
    annotated_img = face_detector.annotate(img, faces, result)
    result["annotated_image"] = encode_image(annotated_img)

    # Track session history
    if session_id:
        if session_id not in sessions:
            sessions[session_id] = []
        sessions[session_id].append({
            "timestamp": result["timestamp"],
            "is_live": result["is_live"],
            "liveness_score": result["liveness_score"],
            "alert": result["alert"]["type"] if result["alert"] else None,
        })

    return jsonify(result)


@app.route("/api/session/<session_id>", methods=["GET"])
def get_session(session_id):
    """Return session alert history."""
    history = sessions.get(session_id, [])
    alerts = [e for e in history if e["alert"]]
    return jsonify({
        "session_id": session_id,
        "total_frames": len(history),
        "alerts": alerts,
        "alert_count": len(alerts),
    })


@app.route("/api/registered_students", methods=["GET"])
def get_registered_students():
    return jsonify({"students": face_recognizer.list_students()})


if __name__ == "__main__":
    logger.info("ProctorGuard backend starting on http://localhost:5000")
    app.run(debug=True, host="0.0.0.0", port=5000)
